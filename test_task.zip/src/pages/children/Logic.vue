<template>
    <div>

    </div>
</template>

<script>
    export default {
        name: "Logic"
    }
</script>

<style scoped>

</style>