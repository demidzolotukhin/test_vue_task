<template>
    <div>





    </div>


</template>

<script>
    export default {
        name: "Questions"
    }
</script>

<style scoped>

</style>