<template>
    <div>

    </div>
</template>

<script>
    export default {
        name: "Condition"
    }
</script>

<style scoped>

</style>