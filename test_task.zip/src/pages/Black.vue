<template>
    <div>

    </div>
</template>

<script>
    export default {
        name: "Black"
    }
</script>

<style scoped>

</style>