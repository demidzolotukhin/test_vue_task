<template>
    <div>

    </div>
</template>

<script>
    export default {
        name: "CallCenter"
    }
</script>

<style scoped>

</style>